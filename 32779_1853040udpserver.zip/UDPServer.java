import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.Executors;

public class UDPServer implements Runnable {
    @Override
    public void run() {
        System.out.println("--------服务端UDP数据监控开始--------");
        while (true) {
          try{
            
            DatagramSocket datagramSocket = new DatagramSocket(5689);
            byte[] bArr = new byte[1024];
            DatagramPacket datagramPacket = new DatagramPacket(bArr, bArr.length);
            try {
                datagramSocket.receive(datagramPacket);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Calendar instance = Calendar.getInstance();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM月dd日hh时mm分ss秒");
            String str = new String(bArr, 0, datagramPacket.getLength());
            System.out.println(new StringBuffer().append(new StringBuffer().append(simpleDateFormat.format(instance.getTime())).append(" 客户端向服务端发送内容为：").toString()).append(str).toString());
            InetAddress address = datagramPacket.getAddress();
            int port = datagramPacket.getPort();
            byte[] bytes = new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(simpleDateFormat.format(instance.getTime())).append(" 客户端发送内容：").toString()).append(str).toString()).append(" 接收成功").toString().getBytes();
            try {
                datagramSocket.send(new DatagramPacket(bytes, bytes.length, address, port));
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            try {
                datagramSocket.close();
            } catch (Exception e3) {
                e3.printStackTrace();
            }
            
            
          }
          catch (Exception e4)
          {}
        }
    }

    public static void main(String[] strArr) {
        Executors.newCachedThreadPool().execute(new UDPServer());
    }
}